package com.baek.findcomment.model;

import com.baek.find.model.FindDAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class FindReplyDAO {
	//싱글톤 형태의 클래스로 생성하는 편이 좋다.(싱글톤 - 여러개 호출되어도 한개의 객체만 반환)
	//1. 나 자신의 객체를 스태틱으로 선언
	private static FindReplyDAO instance = new FindReplyDAO();
	//2. 직접 생성하지 못하도록 생성자 제한
	private FindReplyDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	//3. getter를 통해서 객체를 반환
	public static FindReplyDAO getInstance() {
		return instance;
	}
	//데이터베이스 연결주소
	//오라클 커넥터
	private String url="jdbc:oracle:thin:@172.30.1.14:1521:xe";
	private String uid="PROJSP";
	private String upw="PROJSP";

	public ArrayList<FindReplyVO> listComment(String num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {

			// 부모글 번호를 조건으로 받기
			String sql = "select * from findreply where parentidx=?";
			conn=DriverManager.getConnection(url,uid,upw);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, num);

			rs = pstmt.executeQuery();

			ArrayList<FindReplyVO> clist = new ArrayList<FindReplyVO>();

			while ( rs.next() ) {

				FindReplyVO dto = new FindReplyVO(rs.getString("idx"),
						rs.getString("parentidx"),rs.getString("body"),
						rs.getString("id"),rs.getTimestamp("regdate"));


				clist.add(dto);

			}

			return clist;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
	public void addComment(FindReplyVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into findreply"
				+ " values (replySQ.nextVal, ?, ?, ?, sysdate)";
		try {


			conn=DriverManager.getConnection(url,uid,upw);
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getParentidx());
			pstmt.setString(2, vo.getBody());
			pstmt.setString(3, vo.getId());

			pstmt.executeUpdate(); // 성공시 1 실패시 0

		} catch (Exception e) {
			e.printStackTrace();
		}finally {

			try {
				conn.close();
				pstmt.close();
			} catch (SQLException e) {
			}


		}

	}
}
